#importer les bibliothèques / modules
import pygame
from pygame.locals import*
import pickle
from os import path

#initialiser pygame
pygame.init()
clock = pygame.time.Clock()
fps = 60

#configurer la fenêtre et la taille des cases
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("Outer Tales")
tile_size = 40

#les variables
room_x = 0
room_y = 0
exits = []

#charger les images
bg_img = pygame.transform.scale(pygame.image.load("images/floor.jpg"), (1280, 720))

class Player:
    """classe pour gérer le joueur (déplacements, animations, interactions...)"""
    def __init__(self, x, y):
        """choisir l'image du joueur, établir sa position de base..."""
        #définir les listes qui contiennent les images du joueur qu'on va animer
        self.images_walk_right = []
        self.images_walk_left = []
        self.images_walk_up = []
        self.images_walk_down = []
        for number in range(1, 5):
            img_right = pygame.transform.scale(pygame.image.load(f"images/player/player{number}.png"), (tile_size, tile_size))
            self.images_walk_right.append(img_right)
            img_left = pygame.transform.flip(img_right, True, False)
            self.images_walk_left.append(img_left)
            img_up = pygame.transform.rotate(img_right, 90)
            self.images_walk_up.append(img_up)
            img_down = pygame.transform.flip(img_up, False, True)
            self.images_walk_down.append(img_down)
        self.image = self.images_walk_right[0]

        #met en place les variables pour l'animation
        self.animation_cooldown = 5
        self.counter = 0
        self.index = 0
        self.direction = 1

        #pouvoir changer les coordonnées
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        #la vitesse de déplacement
        self.speed = 4

    def move_left(self):
        """gérer le déplacement vers la gauche"""
        self.dx -= self.speed
        self.counter += 1
        self.direction = -1
        
    def move_right(self):
        """gérer le déplacement vers la droite"""
        self.dx += self.speed
        self.counter += 1
        self.direction = 1
        
    def move_up(self):
        """gérer le déplacement vers le haut"""
        self.dy -= self.speed
        self.counter += 1
        self.direction = -2
        
    def move_down(self):
        """gérer le déplacement vers le bas"""
        self.dy += self.speed
        self.counter += 1
        self.direction = 2

    def change_animation(self):
        """changer l'animation selon la direction vers laquelle le joueur se dirige"""
        if self.direction == 1:
            self.image = self.images_walk_right[self.index]
        elif self.direction == -1:
            self.image = self.images_walk_left[self.index]
        elif self.direction == 2:
            self.image = self.images_walk_down[self.index]
        elif self.direction == -2:
            self.image = self.images_walk_up[self.index]

    def collisions_map(self, tile):
        """gérer les collisions avec les blocs"""
        if tile[1].colliderect(self.rect.x + self.dx, self.rect.y, self.image.get_width(), self.image.get_height()):
            self.dx = 0
        if tile[1].colliderect(self.rect.x, self.rect.y + self.dy, self.image.get_width(), self.image.get_height()):
            self.dy = 0

    def update(self):
        """gérer tous les évènements"""
        global room_x, room_y
        #d'abord les déplacements
        self.dx = 0
        self.dy = 0
        key = pygame.key.get_pressed()
        if key[pygame.K_UP]:
            self.move_up()
        if key[pygame.K_LEFT]:
            self.move_left()
        if key[pygame.K_DOWN]:
            self.move_down()
        if key[pygame.K_RIGHT]:
            self.move_right()
        if key[pygame.K_UP] == False and key[pygame.K_LEFT] == False and key[pygame.K_UP] == False and key[pygame.K_DOWN] == False:
            self.index = 0
            self.counter = 0
            self.change_animation()
            
        #le changement d'animation
        if self.counter > self.animation_cooldown:
            self.counter = 0
            self.index += 1
            if self.index >= len(self.images_walk_right):
                self.index = 0
            self.change_animation()
            
        #les collisions  
        for tile in Map(rooms[room_y][room_x]).tile_list:
            self.collisions_map(tile)
        
        #gérer les collisions avec les portes de sorties
        for exit in exits:
            if exit.rect.colliderect(self.rect.x, self.rect.y, self.image.get_width(), self.image.get_height()):
                if exit.valeur == 'X':
                    room_x += 1
                    self.rect.x = 40
                elif exit.valeur == 'x':
                    room_x -= 1
                    self.rect.x = 1280 - tile_size * 2
                elif exit.valeur == 'Y':
                    room_y += 1
                    self.rect.y = 40
                elif exit.valeur == 'y':
                    room_y -= 1
                    self.rect.y = 720 - tile_size * 2
                
        #déplacer le joueur et le dessiner
        self.rect.x += self.dx
        self.rect.y += self.dy
        screen.blit(self.image, self.rect)
        
class Map:
    """classe pour pouvoir dessiner la room"""
    def __init__(self, liste):
        """créer une liste contient les images et les coordonnées à dessiner"""
        global exits
        exits = []
        self.tile_list = []
        decal = 0

        #charger les images des blocs
        wall_img = pygame.image.load("images/wall.png")
    
        row_count = 0
        for row in liste:
            col_count = 0
            for tile in row:
                if tile == 1:
                    img = pygame.transform.scale(wall_img, (tile_size, tile_size))
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                if tile in ["x", "X", "y", "Y"]:
                    if tile in ["X", "Y"]:
                        decal = tile_size - 1
                    exit = Exit(col_count * tile_size + decal, row_count * tile_size, tile)
                    exits.append(exit)
                col_count += 1
            row_count += 1

    def draw(self):
        """méthode pour dessiner cette liste qui contient toutes les coordonnées et les images des blocs à placer"""
        for tile in self.tile_list:
            screen.blit(tile[0], tile[1])

class Exit:
    def __init__(self, x, y, val):
        img = pygame.image.load("images/exit.png")
        self.image = pygame.transform.scale(img, (1, tile_size))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.valeur = val
        #screen.blit(self.image, self.rect)
#pouvoir importer les salles
#def import_room():
    #global rooms
    #"""importer le fichier binaire qui contient la liste de la salle"""
if path.exists(f"rooms/room1.bin"):
    pickle_in = open(f"rooms/room1.bin", "rb")
    room1 = pickle.load(pickle_in)
if path.exists(f"rooms/room2.bin"):
    pickle_in = open(f"rooms/room2.bin", "rb")
    room2 = pickle.load(pickle_in)
if path.exists(f"rooms/room3.bin"):
    pickle_in = open(f"rooms/room3.bin", "rb")
    room3 = pickle.load(pickle_in)
if path.exists(f"rooms/room4.bin"):
    pickle_in = open(f"rooms/room4.bin", "rb")
    room4 = pickle.load(pickle_in)
rooms = [
    [room1, room2],
    [room3, room4]
]
#on initialise le joueur
player = Player(40, 40)
#import_room()
#lancer la boucle du jeu
run = True
while run:
    #régler la clock sur 60 fps
    clock.tick(fps)

    #charger le sol
    screen.blit(bg_img, (0, 0))

    #charger la map et mettre à jour le joueur
    Map(rooms[room_y][room_x]).draw()
    #print(exits)
    
    player.update()

    #permet de  quitter le jeu
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    #rafrachir l'écran
    pygame.display.update()

pygame.quit()